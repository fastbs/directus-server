-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_folders
DROP TABLE IF EXISTS `directus_folders`;
CREATE TABLE IF NOT EXISTS `directus_folders` (
  `id` char(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `directus_folders_parent_foreign` (`parent`),
  CONSTRAINT `directus_folders_parent_foreign` FOREIGN KEY (`parent`) REFERENCES `directus_folders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_folders: ~7 rows (приблизительно)
INSERT INTO `directus_folders` (`id`, `name`, `parent`) VALUES
	('2d89c3bf-505c-4ebf-acc3-fc3d7c0ac803', 'Private Admin 3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL),
	('3088d1c0-4981-44f9-9eaf-0515c7b41fbe', 'Private Zais ce188df2-446b-485b-82b6-c086c3c16c51', NULL),
	('456f41cb-c43d-4e47-b019-5867bd863a72', 'Zais Folder', NULL),
	('4dc32d35-68e9-4476-91ff-2e6da2b1916c', 'Private - Hidden from all', NULL),
	('5ae79ceb-3e85-42f4-a790-d8cf968dedf3', 'Admin Folder', NULL),
	('96722bd1-8e57-4d8c-bf11-b555dbf36c34', 'Private Zais Second ce188df2-446b-485b-82b6-c086c3c16c51', NULL),
	('9e16651f-f221-4b22-a7ff-d04cc325aadb', 'Map images', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
