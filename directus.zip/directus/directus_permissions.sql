-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_permissions
CREATE TABLE IF NOT EXISTS `directus_permissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `role` char(36) DEFAULT NULL,
  `collection` varchar(64) NOT NULL,
  `action` varchar(10) NOT NULL,
  `permissions` json DEFAULT NULL,
  `validation` json DEFAULT NULL,
  `presets` json DEFAULT NULL,
  `fields` text,
  PRIMARY KEY (`id`),
  KEY `directus_permissions_collection_foreign` (`collection`),
  KEY `directus_permissions_role_foreign` (`role`),
  CONSTRAINT `directus_permissions_role_foreign` FOREIGN KEY (`role`) REFERENCES `directus_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_permissions: ~78 rows (приблизительно)
INSERT INTO `directus_permissions` (`id`, `role`, `collection`, `action`, `permissions`, `validation`, `presets`, `fields`) VALUES
	(16, NULL, 'menu', 'read', '{"_and": [{"roles": {"_contains": "Public"}}]}', NULL, NULL, 'id,parent,name,route,icon,roles'),
	(17, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'menu', 'read', '{"_and": [{"roles": {"_contains": "Publisher"}}]}', NULL, NULL, 'id,icon,parent,name,route,roles'),
	(18, 'de636685-39f5-4119-8368-4410df3656ab', 'menu', 'read', '{"_and": [{"roles": {"_contains": "User"}}]}', NULL, NULL, 'id,icon,parent,name,route,roles'),
	(42, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'posts', 'create', '{}', '{}', NULL, 'sort,title,description,category_id,status,image,category,file,file2'),
	(43, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'posts', 'read', '{}', '{}', NULL, '*'),
	(44, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'posts', 'update', '{}', '{}', NULL, 'status,sort,title,description,category_id,image,category,file,file2'),
	(45, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'posts', 'delete', '{}', '{}', NULL, '*'),
	(47, 'de636685-39f5-4119-8368-4410df3656ab', 'posts', 'create', NULL, '{"_and": [{"user_created": {"_eq": "$CURRENT_USER"}}]}', NULL, 'status,title,description,category_id,image,category,file'),
	(48, 'de636685-39f5-4119-8368-4410df3656ab', 'posts', 'read', '{}', '{}', NULL, '*'),
	(49, 'de636685-39f5-4119-8368-4410df3656ab', 'posts', 'update', '{"_and": [{"user_created": {"_eq": "$CURRENT_USER"}}]}', NULL, NULL, 'status,title,category_id,description,image,category,file'),
	(50, 'de636685-39f5-4119-8368-4410df3656ab', 'posts', 'delete', '{"_and": [{"user_created": {"_eq": "$CURRENT_USER"}}]}', NULL, NULL, NULL),
	(51, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'post_categories', 'read', '{}', '{}', NULL, '*'),
	(52, 'de636685-39f5-4119-8368-4410df3656ab', 'post_categories', 'read', '{}', '{}', NULL, '*'),
	(56, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_users', 'read', '{"_and": [{"id": {"_nnull": true}}]}', NULL, NULL, 'first_name,last_name,email,avatar,location,description,title,role,id'),
	(57, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_files', 'read', '{"_and": [{"_or": [{"folder": {"name": {"_null": true}}}, {"folder": {"name": {"_ncontains": "Private"}}}, {"_and": [{"folder": {"name": {"_contains": "$CURRENT_USER"}}}, {"folder": {"name": {"_contains": "Private"}}}]}]}]}', '{}', NULL, '*'),
	(59, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_roles', 'read', '{"_and": [{"id": {"_nnull": true}}]}', NULL, NULL, 'id,name,icon,description'),
	(60, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_users', 'update', '{"_and": [{"id": {"_eq": "$CURRENT_USER"}}]}', NULL, NULL, 'first_name,last_name,password,email,avatar,title,description,location'),
	(61, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_files', 'read', '{"_and": [{"_or": [{"folder": {"name": {"_null": true}}}, {"folder": {"name": {"_ncontains": "Private"}}}, {"_and": [{"folder": {"name": {"_contains": "$CURRENT_USER"}}}, {"folder": {"name": {"_contains": "Private"}}}]}]}]}', '{}', NULL, '*'),
	(64, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_files', 'create', '{}', '{}', NULL, '*'),
	(66, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_files', 'update', '{"_and": [{"uploaded_by": {"_eq": "$CURRENT_USER"}}]}', '{}', NULL, '*'),
	(67, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_files', 'delete', '{"_and": [{"uploaded_by": {"_eq": "$CURRENT_USER"}}]}', NULL, NULL, NULL),
	(68, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_folders', 'read', '{"_and": [{"_or": [{"name": {"_ncontains": "Private"}}, {"_and": [{"name": {"_contains": "$CURRENT_USER"}}, {"name": {"_contains": "Private"}}]}]}]}', '{}', NULL, '*'),
	(73, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_users', 'read', '{"_and": [{"id": {"_nnull": true}}]}', NULL, NULL, 'first_name,last_name,email,avatar,location,title,description,role,id'),
	(74, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_users', 'update', '{"_and": [{"id": {"_eq": "$CURRENT_USER"}}]}', NULL, NULL, 'first_name,last_name,password,email,location,avatar,title,description'),
	(76, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_files', 'create', '{}', '{}', NULL, '*'),
	(77, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_files', 'update', '{"_and": [{"uploaded_by": {"_eq": "$CURRENT_USER"}}]}', '{}', NULL, '*'),
	(78, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_files', 'delete', '{"_and": [{"uploaded_by": {"_eq": "$CURRENT_USER"}}]}', '{}', NULL, '*'),
	(79, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_folders', 'read', '{"_and": [{"_or": [{"name": {"_ncontains": "Private"}}, {"_and": [{"name": {"_contains": "$CURRENT_USER"}}, {"name": {"_contains": "Private"}}]}]}]}', '{}', NULL, '*'),
	(80, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_folders', 'create', NULL, '{"_and": [{"parent": {"_null": true}}]}', NULL, 'id,parent,name'),
	(85, '5691d77d-1d7a-4a1a-83fa-b717f68726b0', 'menu', 'read', '{"_and": [{"roles": {"_contains": "Guest"}}]}', '{}', NULL, '*'),
	(118, '5691d77d-1d7a-4a1a-83fa-b717f68726b0', 'directus_users', 'read', '{"_and": [{"id": {"_nnull": true}}]}', '{}', NULL, 'first_name,last_name,email,password,avatar,location,title,description,tags,preferences_divider,language,tfa_secret,appearance,theme_light,theme_dark,status,role,id,last_page'),
	(119, '5691d77d-1d7a-4a1a-83fa-b717f68726b0', 'directus_roles', 'read', '{"_and": [{"id": {"_nnull": true}}]}', '{}', NULL, 'id,name,icon,description,users'),
	(120, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_roles', 'read', '{"_and": [{"id": {"_nnull": true}}]}', '{}', NULL, 'id,name,icon,description,users'),
	(122, '5691d77d-1d7a-4a1a-83fa-b717f68726b0', 'directus_users', 'create', NULL, '{"_and": [{"role": {"_eq": "de636685-39f5-4119-8368-4410df3656ab"}}]}', NULL, 'first_name,email,password,role'),
	(123, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_permissions', 'read', '{"_and": [{"role": {"id": {"_eq": "$CURRENT_ROLE"}}}]}', '{}', NULL, '*'),
	(124, 'de636685-39f5-4119-8368-4410df3656ab', 'directus_folders', 'create', NULL, '{"_and": [{"parent": {"_null": true}}]}', NULL, 'id,parent,name'),
	(125, NULL, 'directus_files', 'read', '{}', '{}', NULL, '*'),
	(127, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'companies', 'create', '{}', '{}', NULL, 'name,name_short,inn'),
	(130, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'companies', 'read', '{}', '{}', NULL, '*'),
	(131, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'companies', 'update', NULL, NULL, NULL, 'name,inn,name_short'),
	(133, 'de636685-39f5-4119-8368-4410df3656ab', 'companies', 'create', NULL, NULL, NULL, 'name_short,inn,name'),
	(134, 'de636685-39f5-4119-8368-4410df3656ab', 'companies', 'read', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'id,user_updated,name_short,inn,date_updated,user_created,date_created,name'),
	(135, 'de636685-39f5-4119-8368-4410df3656ab', 'companies', 'update', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'name_short,inn,name'),
	(136, 'de636685-39f5-4119-8368-4410df3656ab', 'companies', 'delete', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, NULL),
	(137, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'companies', 'delete', '{}', '{}', NULL, '*'),
	(138, 'de636685-39f5-4119-8368-4410df3656ab', 'jobtitles', 'read', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', '{}', NULL, '*'),
	(139, 'de636685-39f5-4119-8368-4410df3656ab', 'jobtitles', 'update', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', '{}', NULL, 'name,name_short,company'),
	(140, 'de636685-39f5-4119-8368-4410df3656ab', 'jobtitles', 'delete', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, NULL),
	(141, 'de636685-39f5-4119-8368-4410df3656ab', 'jobtitles', 'create', NULL, NULL, NULL, 'name,company,name_short'),
	(142, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'jobtitles', 'create', NULL, NULL, NULL, 'name,company,name_short'),
	(143, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'jobtitles', 'read', '{}', '{}', NULL, '*'),
	(144, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'jobtitles', 'update', NULL, NULL, NULL, 'name,company,name_short'),
	(145, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'jobtitles', 'delete', '{}', '{}', NULL, '*'),
	(146, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'employees', 'read', '{}', '{}', NULL, '*'),
	(147, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'employees', 'delete', '{}', '{}', NULL, '*'),
	(148, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'employees', 'update', NULL, NULL, NULL, 'name,company,name_short'),
	(149, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'employees', 'create', NULL, NULL, NULL, 'name,company,name_short'),
	(150, 'de636685-39f5-4119-8368-4410df3656ab', 'employees', 'create', NULL, NULL, NULL, 'name,company,name_short'),
	(151, 'de636685-39f5-4119-8368-4410df3656ab', 'employees', 'read', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'id,user_created,date_created,name,date_updated,user_updated,name_short,company'),
	(152, 'de636685-39f5-4119-8368-4410df3656ab', 'employees', 'update', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'name,company,name_short'),
	(153, 'de636685-39f5-4119-8368-4410df3656ab', 'employees', 'delete', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, NULL),
	(154, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_images', 'read', '{}', '{}', NULL, '*'),
	(155, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_points', 'read', '{}', '{}', NULL, '*'),
	(156, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_points', 'create', '{}', '{}', NULL, '*'),
	(157, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_points', 'update', '{}', '{}', NULL, '*'),
	(158, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_points', 'delete', '{}', '{}', NULL, '*'),
	(162, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'directus_permissions', 'read', '{"_and": [{"role": {"id": {"_eq": "$CURRENT_ROLE"}}}]}', NULL, NULL, NULL),
	(163, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_markers', 'create', '{}', '{}', NULL, '*'),
	(164, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_markers', 'read', '{}', '{}', NULL, '*'),
	(165, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_markers', 'update', '{}', '{}', NULL, '*'),
	(166, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'map_markers', 'delete', '{}', '{}', NULL, '*'),
	(168, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'investigations', 'read', '{}', '{}', NULL, '*'),
	(170, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'investigations', 'delete', '{}', '{}', NULL, '*'),
	(171, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'investigations', 'create', NULL, NULL, NULL, 'title,company,description,image,content,state'),
	(172, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'investigations', 'update', NULL, NULL, NULL, 'title,company,description,state,content,image'),
	(173, 'de636685-39f5-4119-8368-4410df3656ab', 'investigations', 'read', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'id,user_updated,description,company,date_updated,user_created,date_created,title,state,content,image'),
	(174, 'de636685-39f5-4119-8368-4410df3656ab', 'investigations', 'create', NULL, NULL, NULL, 'title,company,description,state,content'),
	(175, 'de636685-39f5-4119-8368-4410df3656ab', 'investigations', 'update', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, 'title,company,description,state,content,image'),
	(176, 'de636685-39f5-4119-8368-4410df3656ab', 'investigations', 'delete', '{"_and": [{"user_created": {"id": {"_eq": "$CURRENT_USER"}}}]}', NULL, NULL, NULL),
	(177, '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'reports', 'read', '{}', '{}', NULL, '*'),
	(178, 'de636685-39f5-4119-8368-4410df3656ab', 'reports', 'read', '{}', '{}', NULL, '*');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
