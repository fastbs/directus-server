-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_fields
DROP TABLE IF EXISTS `directus_fields`;
CREATE TABLE IF NOT EXISTS `directus_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `collection` varchar(64) NOT NULL,
  `field` varchar(64) NOT NULL,
  `special` varchar(64) DEFAULT NULL,
  `interface` varchar(64) DEFAULT NULL,
  `options` json DEFAULT NULL,
  `display` varchar(64) DEFAULT NULL,
  `display_options` json DEFAULT NULL,
  `readonly` tinyint(1) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `sort` int unsigned DEFAULT NULL,
  `width` varchar(30) DEFAULT 'full',
  `translations` json DEFAULT NULL,
  `note` text,
  `conditions` json DEFAULT NULL,
  `required` tinyint(1) DEFAULT '0',
  `group` varchar(64) DEFAULT NULL,
  `validation` json DEFAULT NULL,
  `validation_message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_fields: ~90 rows (приблизительно)
INSERT INTO `directus_fields` (`id`, `collection`, `field`, `special`, `interface`, `options`, `display`, `display_options`, `readonly`, `hidden`, `sort`, `width`, `translations`, `note`, `conditions`, `required`, `group`, `validation`, `validation_message`) VALUES
	(25, 'menu', 'parent', NULL, NULL, NULL, NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(26, 'menu', 'id', NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(27, 'menu', 'name', NULL, NULL, NULL, NULL, NULL, 0, 0, 3, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(28, 'menu', 'route', NULL, NULL, NULL, NULL, NULL, 0, 0, 4, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(29, 'menu', 'icon', NULL, NULL, NULL, NULL, NULL, 0, 0, 5, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(30, 'menu', 'roles', NULL, NULL, NULL, NULL, NULL, 0, 0, 6, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(43, 'posts', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(44, 'posts', 'status', NULL, 'select-dropdown', '{"choices": [{"text": "$t:published", "value": "published"}, {"text": "$t:draft", "value": "draft"}, {"text": "$t:archived", "value": "archived"}]}', 'labels', '{"choices": [{"text": "$t:published", "value": "published", "background": "var(--theme--primary)", "foreground": "#FFFFFF"}, {"text": "$t:draft", "value": "draft", "background": "#D3DAE4", "foreground": "#18222F"}, {"text": "$t:archived", "value": "archived", "background": "var(--theme--warning)", "foreground": "#FFFFFF"}], "showAsDot": true}', 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(45, 'posts', 'sort', NULL, 'input', NULL, NULL, NULL, 0, 1, 3, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(46, 'posts', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(47, 'posts', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(48, 'posts', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 6, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(49, 'posts', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 7, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(50, 'posts', 'title', NULL, 'input', NULL, NULL, NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(51, 'posts', 'description', NULL, 'input-multiline', NULL, NULL, NULL, 0, 0, 9, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(52, 'post_categories', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(53, 'post_categories', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(57, 'post_categories', 'description', NULL, 'input-multiline', NULL, NULL, NULL, 0, 0, 3, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(58, 'posts', 'image', 'file', 'file-image', NULL, NULL, NULL, 0, 0, 11, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(61, 'posts', 'category', 'm2o', 'select-dropdown-m2o', '{"template": "{{name}}"}', 'related-values', '{"template": "{{name}}"}', 0, 0, 10, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(64, 'companies', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(65, 'companies', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 2, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(66, 'companies', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 3, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(67, 'companies', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(68, 'companies', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(69, 'companies', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 6, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(70, 'companies', 'name_short', NULL, 'input', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(71, 'companies', 'inn', NULL, 'input', NULL, NULL, NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(72, 'jobtitles', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(73, 'jobtitles', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 2, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(74, 'jobtitles', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 3, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(75, 'jobtitles', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(76, 'jobtitles', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(77, 'jobtitles', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 6, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(78, 'jobtitles', 'name_short', NULL, 'input', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(81, 'jobtitles', 'company', 'm2o', 'select-dropdown-m2o', '{"template": "{{name}}"}', 'related-values', '{"template": "{{name}}"}', 0, 0, 8, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(82, 'creation_rules', 'id', NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(84, 'creation_rules', 'field', NULL, NULL, NULL, NULL, NULL, 0, 0, 4, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(87, 'employees', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(88, 'employees', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 2, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(89, 'employees', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 3, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(90, 'employees', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(91, 'employees', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(92, 'employees', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 6, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(93, 'employees', 'name_short', NULL, 'input', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(94, 'employees', 'company', 'm2o', 'select-dropdown-m2o', '{"template": "{{name}}"}', 'related-values', NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(97, 'fastbs_bundle_rules', 'rule', 'cast-json', 'input-code', NULL, NULL, NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(98, 'fastbs_bundle_rules', 'errorMessage', NULL, 'input', '{"placeholder": "Сообщение об ошибке"}', NULL, NULL, 0, 0, 10, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(99, 'fastbs_bundle_rules', 'name', NULL, 'input', '{"placeholder": "Имя правила"}', NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(100, 'fastbs_bundle_rules', 'success', 'cast-boolean', 'boolean', '{"label": "Условие для правила", "colorOn": "#3399FF", "colorOff": "#E35169"}', 'boolean', '{"colorOn": "#3399FF", "labelOn": "TRUE", "colorOff": "#E35169", "labelOff": "FALSE"}', 0, 0, 9, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(103, 'fastbs_bundle_rules', 'id', NULL, NULL, NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(105, 'fastbs_bundle_rules', 'active', 'cast-boolean', 'boolean', '{"label": "Правило активно", "colorOn": "#3399FF", "colorOff": "#E35169"}', NULL, NULL, 0, 0, 11, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(114, 'fastbs_bundle_rules', 'collection', NULL, 'fastbs.collection.selector', '{"placeholder": "Коллекция"}', NULL, NULL, 0, 0, 3, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(115, 'fastbs_bundle_rules', 'related_collection', NULL, 'fastbs.collection.selector', '{"placeholder": "Связанная коллекция"}', NULL, NULL, 0, 0, 4, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(116, 'fastbs_bundle_rules', 'event', NULL, 'select-dropdown', '{"choices": [{"icon": "note_add", "text": "CREATE", "color": "#3399FF", "value": "CREATE"}, {"icon": "edit_document", "text": "UPDATE", "color": "#2ECDA7", "value": "UPDATE"}, {"icon": "scan_delete", "text": "DELETE", "color": "#E35169", "value": "DELETE"}], "placeholder": "Операция"}', 'labels', '{"choices": [{"icon": "note_add", "text": "CREATE", "color": "#3399FF", "value": "CREATE", "foreground": "#3399FF"}, {"icon": "edit_document", "text": "UPDATE", "color": "#2ECDA7", "value": "UPDATE", "foreground": "#2ECDA7"}, {"icon": "scan_delete", "text": "DELETE", "color": "#E35169", "value": "DELETE", "foreground": "#E35169"}]}', 0, 0, 6, 'full', NULL, NULL, NULL, 1, NULL, NULL, NULL),
	(117, 'posts', 'test', 'cast-json', 'filters', '{"properties": {"age": "integer", "meta": {"now": "dateTime", "active": "boolean"}, "name": {"name": "Full name", "type": "string"}, "gender": {"type": "string", "choices": [{"text": "Male", "value": "male"}, {"text": "Female", "value": "female"}]}, "country": {"type": "string", "choices": "$COUNTRIES"}}}', NULL, NULL, 0, 0, 12, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(124, 'qq', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(125, 'qq', 'qq', NULL, 'input', NULL, NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(126, 'fastbs_bundle_settings', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(127, 'fastbs_bundle_settings', 'rules_collection', NULL, 'input', NULL, NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(128, 'map_points', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(129, 'map_points', 'x', NULL, 'input', NULL, NULL, NULL, 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(130, 'map_points', 'y', NULL, 'input', NULL, NULL, NULL, 0, 0, 3, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(133, 'map_images', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(134, 'map_images', 'status', NULL, 'select-dropdown', '{"choices": [{"text": "$t:published", "color": "var(--theme--primary)", "value": "published"}, {"text": "$t:draft", "color": "var(--theme--foreground)", "value": "draft"}, {"text": "$t:archived", "color": "var(--theme--warning)", "value": "archived"}]}', 'labels', '{"choices": [{"text": "$t:published", "color": "var(--theme--primary)", "value": "published", "background": "var(--theme--primary-background)", "foreground": "var(--theme--primary)"}, {"text": "$t:draft", "color": "var(--theme--foreground)", "value": "draft", "background": "var(--theme--background-normal)", "foreground": "var(--theme--foreground)"}, {"text": "$t:archived", "color": "var(--theme--warning)", "value": "archived", "background": "var(--theme--warning-background)", "foreground": "var(--theme--warning)"}], "showAsDot": true}', 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(135, 'map_images', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 3, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(136, 'map_images', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(137, 'map_images', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(138, 'map_images', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 6, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(139, 'map_images', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(140, 'map_images', 'image', 'file', 'file-image', '{"crop": false}', NULL, NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(141, 'map_images', 'point1', 'm2o', 'select-dropdown-m2o', NULL, NULL, NULL, 0, 0, 9, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(142, 'map_images', 'point2', 'm2o', 'select-dropdown-m2o', NULL, NULL, NULL, 0, 0, 10, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(145, 'map_points', 'lat', NULL, 'input', NULL, NULL, NULL, 0, 0, 4, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(146, 'map_points', 'lng', NULL, 'input', NULL, NULL, NULL, 0, 0, 5, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(147, 'map_points', 'comment', NULL, 'input', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(148, 'map_points', 'map_image', 'm2o', 'select-dropdown-m2o', NULL, NULL, NULL, 0, 0, 6, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(149, 'map_markers', 'id', NULL, 'input', NULL, NULL, NULL, 1, 1, 1, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(150, 'map_markers', 'status', NULL, 'select-dropdown', '{"choices": [{"text": "$t:published", "color": "var(--theme--primary)", "value": "published"}, {"text": "$t:draft", "color": "var(--theme--foreground)", "value": "draft"}, {"text": "$t:archived", "color": "var(--theme--warning)", "value": "archived"}]}', 'labels', '{"choices": [{"text": "$t:published", "color": "var(--theme--primary)", "value": "published", "background": "var(--theme--primary-background)", "foreground": "var(--theme--primary)"}, {"text": "$t:draft", "color": "var(--theme--foreground)", "value": "draft", "background": "var(--theme--background-normal)", "foreground": "var(--theme--foreground)"}, {"text": "$t:archived", "color": "var(--theme--warning)", "value": "archived", "background": "var(--theme--warning-background)", "foreground": "var(--theme--warning)"}], "showAsDot": true}', 0, 0, 2, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(151, 'map_markers', 'user_created', 'user-created', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 3, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(152, 'map_markers', 'date_created', 'date-created', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 4, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(153, 'map_markers', 'user_updated', 'user-updated', 'select-dropdown-m2o', '{"template": "{{avatar.$thumbnail}} {{first_name}} {{last_name}}"}', 'user', NULL, 1, 1, 5, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(154, 'map_markers', 'date_updated', 'date-updated', 'datetime', NULL, 'datetime', '{"relative": true}', 1, 1, 6, 'half', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(155, 'map_markers', 'x', NULL, 'input', NULL, NULL, NULL, 0, 0, 8, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(156, 'map_markers', 'y', NULL, 'input', NULL, NULL, NULL, 0, 0, 9, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(157, 'map_markers', 'lat', NULL, 'input', NULL, NULL, NULL, 0, 0, 10, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(158, 'map_markers', 'lng', NULL, 'input', NULL, NULL, NULL, 0, 0, 11, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(159, 'map_markers', 'name', NULL, 'input', NULL, NULL, NULL, 0, 0, 12, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(160, 'map_markers', 'comment', NULL, 'input', NULL, NULL, NULL, 0, 0, 13, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL),
	(161, 'map_markers', 'map_image', 'm2o', 'select-dropdown-m2o', NULL, NULL, NULL, 0, 0, 7, 'full', NULL, NULL, NULL, 0, NULL, NULL, NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
