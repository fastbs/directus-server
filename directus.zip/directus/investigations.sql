-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.investigations
CREATE TABLE IF NOT EXISTS `investigations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `company` int unsigned DEFAULT NULL,
  `image` char(36) DEFAULT NULL,
  `state` json DEFAULT (_utf8mb3'{"counter":0,"current_node":""}'),
  `content` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `investigations_user_created_foreign` (`user_created`),
  KEY `investigations_user_updated_foreign` (`user_updated`),
  KEY `investigations_company_foreign` (`company`),
  KEY `investigations_image_foreign` (`image`),
  CONSTRAINT `investigations_company_foreign` FOREIGN KEY (`company`) REFERENCES `companies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `investigations_image_foreign` FOREIGN KEY (`image`) REFERENCES `directus_files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `investigations_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `investigations_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.investigations: ~5 rows (приблизительно)
INSERT INTO `investigations` (`id`, `user_created`, `date_created`, `user_updated`, `date_updated`, `title`, `description`, `company`, `image`, `state`, `content`) VALUES
	(1, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-03-18 16:41:59', NULL, NULL, 'Перенос из MongoDB', 'Импортируем вручную...', 84, '479c8576-863a-4e61-bc0b-02eda9c1e36f', '{"counter": 0, "current_node": ""}', '{"_id": "63f9ca76b8992c3c03c45725", "data": {"director": {"basis": "действующий на основании положения о ____________  от __.__.20__", "employee": "64796a8c9ced30b6fa073ac0", "job_title": "646f0135d44c8a622aacdaa9"}, "directors": [{"basis": "действующий на основании Устава", "ends_at": "2023-06-07T13:00:00.000Z", "employee": "64783552d78b62ed6d6995b9", "job_title": "647921779ced30b6fa073057", "starts_at": "2023-06-06T13:00:00.000Z"}, {"basis": "действующий на основании доверенности №2/2023 от 22.02.2023 г.", "ends_at": "2023-03-31T14:00:00.000Z", "employee": "64796a8c9ced30b6fa073ac0", "job_title": "646f0135d44c8a622aacdaa9", "starts_at": "2023-03-01T14:00:00.000Z"}, {"basis": "действующий на основании приказа №___ от __.__.20__", "ends_at": "2023-06-06T23:43:03.226Z", "employee": "643c86f4ddd7ec0e235ee258", "job_title": "647921779ced30b6fa073057", "starts_at": "2023-06-06T23:43:03.226Z"}, {"basis": "", "ends_at": "2023-06-15T04:31:56.353Z", "employee": "", "job_title": "", "starts_at": "2023-06-15T04:31:56.353Z"}], "is_periodic": false}, "name": "Инициализация", "type": "InitializationBlock", "children": [{"_id": "640558dde8784f4b4595623e", "data": {"counter": 1, "my_string": "Строка текста"}, "name": "Фиксация нарушения", "type": "FixationBlock", "children": [{"_id": "64055996e8784f4b4595623f", "data": {"counter": 3, "new_string": "Опять строка текста"}, "name": "Утверждение руководителем", "type": "BossAcceptBlock", "is_ready": false}, {"_id": "64055a4ae8784f4b45956240", "data": {"directors": [{"basis": "действующий на основании Устава", "position": "Генеральный директор", "person_id": "64053512e8784f4b45956221", "is_periodic": false}], "firm_name": "ЗАО \\"Мартышкин труд\\""}, "name": "Фиктивный блок - Инициализация", "type": "InitializationBlock", "is_ready": false}], "is_ready": false}], "is_ready": false}'),
	(2, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-18 16:52:00', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-06-03 19:07:24', 'Расследование юзера', 'Копаем...', 85, 'ff759ccb-d890-48b2-ba67-fe371f33f30e', '{"counter": 0, "current_node": ""}', '{"_id": "64800dd0bf3a97e8e2117569", "data": {"director": {"basis": "действующий на основании положения о ____________  от __.__.20__", "employee": "23", "job_title": "82"}, "directors": [{"basis": "действующий на основании Устава", "ends_at": "2024-06-03T04:54:57.979Z", "employee": "20", "job_title": "4", "starts_at": "2024-06-03T04:54:57.979Z"}, {"basis": "действующий на основании доверенности №___ от __.__.20__", "ends_at": "2024-06-04T13:00:00.000Z", "employee": "22", "job_title": "81", "starts_at": "2024-06-03T13:00:00.000Z"}, {"basis": "", "ends_at": "2024-06-04T06:06:40.817Z", "employee": "", "job_title": "", "starts_at": "2024-06-04T06:06:40.817Z"}], "is_periodic": false}, "name": "Инициализация из скрипта", "type": "InitializationBlock", "children": [{"_id": "8063d552-0dda-41e1-a358-3325d3f3e71c", "data": {"signers": [{}], "submitter": {"position": "", "employee_id": ""}, "violators": [{}]}, "name": "Фиксация нарушения", "type": "FixationBlock", "children": [{"_id": "2995b86b-1c35-4f19-a31d-e319df6bf209", "data": {"counter": 3}, "name": "Утверждение руководителем", "type": "BossAcceptBlock", "is_ready": false}], "is_ready": false}], "is_ready": true}'),
	(6, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-26 16:23:55', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-03-26 16:26:01', 'Из нового клиента', 'Описалово', 94, 'da6d644e-2c4e-4f6e-a1e2-6f42eecaf8d2', '{"counter": 0, "current_node": ""}', '{"_id": "d48a4bf0-9b02-4448-83df-36dee0528bec", "data": {"director": {"basis": "действующий на основании Устава", "employee": "21", "job_title": "54"}, "directors": [], "is_periodic": false}, "name": "Инициализация (из клиента)", "type": "InitializationBlock", "children": [{"id": "08b58b3a-741d-4bd6-b2c0-2dd5683d2dae", "data": {"signers": [{}], "submitter": {"position": "", "employee_id": ""}, "violators": [{}]}, "name": "Фиксация нарушения", "type": "FixationBlock", "is_ready": false}], "is_ready": true}'),
	(7, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-06-02 16:27:32', NULL, NULL, '12345', 'jjjjjj', 81, NULL, '{"counter": 0, "current_node": ""}', '{"_id": "8d8b3ad2-1beb-4b27-a050-521779da5bde", "data": {"director": {"basis": "", "employee": "", "job_title": ""}, "directors": [], "is_periodic": false}, "name": "Инициализация (из клиента)", "type": "InitializationBlock", "is_ready": false}'),
	(8, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-06-02 17:38:07', '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-06-02 17:52:30', '111111', '222222', 85, NULL, '{"counter": 0, "current_node": ""}', '{"_id": "f32d5f0d-5f05-451d-b4a1-40d5af637b78", "data": {"director": {"basis": "", "employee": "", "job_title": ""}, "directors": [], "is_periodic": false}, "name": "Инициализация (из клиента)", "type": "InitializationBlock", "is_ready": false}');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
