-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.employees
CREATE TABLE IF NOT EXISTS `employees` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `name_short` varchar(255) DEFAULT NULL,
  `company` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `employees_user_created_foreign` (`user_created`),
  KEY `employees_user_updated_foreign` (`user_updated`),
  KEY `employees_company_foreign` (`company`),
  CONSTRAINT `employees_company_foreign` FOREIGN KEY (`company`) REFERENCES `companies` (`id`),
  CONSTRAINT `employees_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `employees_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.employees: ~9 rows (приблизительно)
INSERT INTO `employees` (`id`, `user_created`, `date_created`, `user_updated`, `date_updated`, `name`, `name_short`, `company`) VALUES
	(1, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-14 19:43:37', NULL, NULL, 'Петров Иван Иваныч', 'Петров И.И.', 81),
	(2, '6013ca28-b4bd-4a96-a2db-bccc6a0510fa', '2024-02-15 01:09:08', NULL, NULL, 'Зайчище Дристунище через пень ногу Задирище', 'Зайчище Д. ч.', 95),
	(3, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-16 20:27:40', NULL, NULL, 'Восьмихуев Чарли Хуевич', 'Восьмихуев Ч. Х.', 81),
	(20, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-18 16:49:12', '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 12:09:30', 'Петров', 'Петров', 85),
	(21, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-21 18:44:26', NULL, NULL, 'Лысый Черт', 'Лысый Ч.', 94),
	(22, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 11:05:06', '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 12:09:30', 'Иванов', 'Иванов', 85),
	(23, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 11:05:26', '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 12:09:30', 'Сидоров', 'Сидоров', 85),
	(28, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 12:56:07', NULL, NULL, 'Кротов', 'Кротов', 85);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
