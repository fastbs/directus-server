-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_relations
CREATE TABLE IF NOT EXISTS `directus_relations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `many_collection` varchar(64) NOT NULL,
  `many_field` varchar(64) NOT NULL,
  `one_collection` varchar(64) DEFAULT NULL,
  `one_field` varchar(64) DEFAULT NULL,
  `one_collection_field` varchar(64) DEFAULT NULL,
  `one_allowed_collections` text,
  `junction_field` varchar(64) DEFAULT NULL,
  `sort_field` varchar(64) DEFAULT NULL,
  `one_deselect_action` varchar(255) NOT NULL DEFAULT 'nullify',
  PRIMARY KEY (`id`),
  KEY `directus_relations_many_collection_foreign` (`many_collection`),
  KEY `directus_relations_one_collection_foreign` (`one_collection`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_relations: ~25 rows (приблизительно)
INSERT INTO `directus_relations` (`id`, `many_collection`, `many_field`, `one_collection`, `one_field`, `one_collection_field`, `one_allowed_collections`, `junction_field`, `sort_field`, `one_deselect_action`) VALUES
	(9, 'posts', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(10, 'posts', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(14, 'posts', 'image', 'directus_files', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(17, 'posts', 'category', 'post_categories', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(20, 'companies', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(21, 'companies', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(22, 'jobtitles', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(23, 'jobtitles', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(25, 'jobtitles', 'company', 'companies', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(26, 'employees', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(27, 'employees', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(28, 'employees', 'company', 'companies', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(32, 'map_images', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(33, 'map_images', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(34, 'map_images', 'image', 'directus_files', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(35, 'map_images', 'point1', 'map_points', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(36, 'map_images', 'point2', 'map_points', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(38, 'map_points', 'map_image', 'map_images', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(39, 'map_markers', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(40, 'map_markers', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(41, 'map_markers', 'map_image', 'map_images', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(42, 'investigations', 'user_created', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(43, 'investigations', 'user_updated', 'directus_users', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(44, 'investigations', 'company', 'companies', NULL, NULL, NULL, NULL, NULL, 'nullify'),
	(45, 'investigations', 'image', 'directus_files', NULL, NULL, NULL, NULL, NULL, 'nullify');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
