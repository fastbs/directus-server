-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_operations
DROP TABLE IF EXISTS `directus_operations`;
CREATE TABLE IF NOT EXISTS `directus_operations` (
  `id` char(36) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `key` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `position_x` int NOT NULL,
  `position_y` int NOT NULL,
  `options` json DEFAULT NULL,
  `resolve` char(36) DEFAULT NULL,
  `reject` char(36) DEFAULT NULL,
  `flow` char(36) NOT NULL,
  `date_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_created` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `directus_operations_resolve_unique` (`resolve`),
  UNIQUE KEY `directus_operations_reject_unique` (`reject`),
  KEY `directus_operations_flow_foreign` (`flow`),
  KEY `directus_operations_user_created_foreign` (`user_created`),
  CONSTRAINT `directus_operations_flow_foreign` FOREIGN KEY (`flow`) REFERENCES `directus_flows` (`id`) ON DELETE CASCADE,
  CONSTRAINT `directus_operations_reject_foreign` FOREIGN KEY (`reject`) REFERENCES `directus_operations` (`id`),
  CONSTRAINT `directus_operations_resolve_foreign` FOREIGN KEY (`resolve`) REFERENCES `directus_operations` (`id`),
  CONSTRAINT `directus_operations_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_operations: ~4 rows (приблизительно)
INSERT INTO `directus_operations` (`id`, `name`, `key`, `type`, `position_x`, `position_y`, `options`, `resolve`, `reject`, `flow`, `date_created`, `user_created`) VALUES
	('76a420f9-7ad6-4252-8dcf-e1fef8316a2f', 'Read Data - JobTitles', 'mf_item_read_jobtitles', 'item-read', 37, 1, '{"query": {"filter": {"user_created": {"_eq": "$CURRENT_USER"}}}, "collection": "jobtitles"}', 'fb1f6be1-883e-4b0f-8d2d-1702e8a16ce3', NULL, '4401d820-5f51-4d74-a1c9-eae84887ff8c', '2024-02-14 01:40:16', '3dc0e39c-4891-473d-8be3-d6080e4b314a'),
	('dfe2a0f9-1421-4d20-9b98-bce301aca193', 'Read Data - Companies', 'mf_item_read_companies', 'item-read', 19, 1, '{"query": {"filter": {"user_created": {"_eq": "$CURRENT_USER"}}}, "collection": "companies"}', '76a420f9-7ad6-4252-8dcf-e1fef8316a2f', NULL, '4401d820-5f51-4d74-a1c9-eae84887ff8c', '2024-02-13 19:15:46', '3dc0e39c-4891-473d-8be3-d6080e4b314a'),
	('fb1f6be1-883e-4b0f-8d2d-1702e8a16ce3', 'Run Script', 'exec_1xiy0', 'exec', 55, 1, '{"code": "module.exports = async function(data) {\\n/*\\nResponse Body — This is optional. Its also only for Filter (Blocking) events.\\nDefines data to replace the event\'s original payload. Choose to return:\\n    Data of Last Operation — Replaces event payload with value from $last.\\n    All Data — Replaces event payload with the entire data chain.\\n    Other — Replaces event payload with value from an <operationKey>.\\n*/    \\n/*\\n    return data.$trigger.payload;\\n    \\n    return {\\n    \\tname: \\"123\\",\\n        name_short: \\"ns\\",\\n        company: 81\\n    };\\n*/    \\n    //console.log(data.mf_item_read_companies);\\n    //console.log(data.mf_item_read_jobtitles);\\n    //console.log(\\"NOW:\\", $NOW);\\n    const check = data.mf_item_read_companies.find(x => x.id == data.$trigger.payload.company);\\n    const check2 = data.mf_item_read_jobtitles.find(x => x.name == data.$trigger.payload.name && x.company==data.$trigger.payload.company);\\n    //console.log(check);\\n    //console.log(check2);\\n    // {\\"payload\\":{\\"name\\":\\"From Main\\",\\"name_short\\":\\"fm\\",\\"company\\":81}\\n\\t// Do something...\\n    if (!check) {\\n        throw new TypeError(\\"Wrong company!\\", { cause: \\"12345\\", code: 404 });\\n    }\\n    if (check2) {\\n    throw new TypeError(\\"Job title already exists!\\");\\n    }\\n\\treturn data.$trigger.payload;\\n}"}', NULL, NULL, '4401d820-5f51-4d74-a1c9-eae84887ff8c', '2024-02-14 01:43:06', '3dc0e39c-4891-473d-8be3-d6080e4b314a');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
