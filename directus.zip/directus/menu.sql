-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.menu
DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `route` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `roles` set('Administrator','Public','Guest','User','Publisher') CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `parent` int DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Дамп данных таблицы directus.menu: ~14 rows (приблизительно)
INSERT INTO `menu` (`id`, `name`, `route`, `icon`, `roles`, `parent`) VALUES
	(1, 'Главная', '/', 'pi pi-fw pi-home', 'Administrator,Public,Guest,User,Publisher', NULL),
	(2, 'Логин', '/user/login', 'pi pi-fw pi-sign-in', 'Public,Guest', NULL),
	(3, 'Регистрация', '/user/registration', 'pi pi-fw pi-user-plus', 'Public,Guest', NULL),
	(10, 'Публикации', '/posts', 'pi pi-fw pi-file', 'Administrator,User,Publisher', NULL),
	(20, 'Справочники', '', 'pi pi-fw pi-info-circle', 'Administrator,User,Publisher', NULL),
	(21, 'Компании', '/references/companies', 'pi pi-fw pi-building', 'Administrator,User,Publisher', 20),
	(22, 'Должности', '/references/jobtitles', 'pi pi-fw pi-id-card', 'Administrator,User,Publisher', 20),
	(23, 'Сотрудники', '/references/employees', 'pi pi-fw pi-user', 'Administrator,User,Publisher', 20),
	(30, 'Расследования', '/investigations', 'pi pi-fw pi-search', 'Administrator,User,Publisher', NULL),
	(40, 'Карты', '', 'pi pi-fw pi-map', 'Administrator,Public,Guest,User,Publisher', NULL),
	(41, 'Делаем', '/maps', 'pi pi-fw pi-map-marker', 'Administrator,User,Publisher', 40),
	(42, 'Примеры', '/maps/examples', 'pi pi-fw pi-list', 'Administrator,Public,Guest,User,Publisher', 40),
	(43, 'Обработка', '/maps/imager', 'pi pi-fw pi-calculator', 'Administrator,User,Publisher', 40),
	(100, 'Выход', '/user/logout', 'pi pi-fw pi-sign-out', 'Administrator,User,Publisher', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
