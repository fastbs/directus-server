-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_files
DROP TABLE IF EXISTS `directus_files`;
CREATE TABLE IF NOT EXISTS `directus_files` (
  `id` char(36) NOT NULL,
  `storage` varchar(255) NOT NULL,
  `filename_disk` varchar(255) DEFAULT NULL,
  `filename_download` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `folder` char(36) DEFAULT NULL,
  `uploaded_by` char(36) DEFAULT NULL,
  `uploaded_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` char(36) DEFAULT NULL,
  `modified_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `charset` varchar(50) DEFAULT NULL,
  `filesize` bigint DEFAULT NULL,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `duration` int unsigned DEFAULT NULL,
  `embed` varchar(200) DEFAULT NULL,
  `description` text,
  `location` text,
  `tags` text,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `directus_files_uploaded_by_foreign` (`uploaded_by`),
  KEY `directus_files_modified_by_foreign` (`modified_by`),
  KEY `directus_files_folder_foreign` (`folder`),
  CONSTRAINT `directus_files_folder_foreign` FOREIGN KEY (`folder`) REFERENCES `directus_folders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `directus_files_modified_by_foreign` FOREIGN KEY (`modified_by`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `directus_files_uploaded_by_foreign` FOREIGN KEY (`uploaded_by`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_files: ~21 rows (приблизительно)
INSERT INTO `directus_files` (`id`, `storage`, `filename_disk`, `filename_download`, `title`, `type`, `folder`, `uploaded_by`, `uploaded_on`, `modified_by`, `modified_on`, `charset`, `filesize`, `width`, `height`, `duration`, `embed`, `description`, `location`, `tags`, `metadata`) VALUES
	('05fc8a2c-6af2-4034-a53e-c53a8a8f6522', 'local', '05fc8a2c-6af2-4034-a53e-c53a8a8f6522.jpg', 'tort.jpg', 'Tort changed', 'image/jpeg', '96722bd1-8e57-4d8c-bf11-b555dbf36c34', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-07 06:37:07', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-07 17:55:09', NULL, 286169, 824, 900, NULL, NULL, NULL, NULL, NULL, '{}'),
	('2906125e-7ca6-4172-aeac-2a1a6ba82b42', 'local', '2906125e-7ca6-4172-aeac-2a1a6ba82b42.jpg', '17683249.jpg', '17683249', 'image/jpeg', '456f41cb-c43d-4e47-b019-5867bd863a72', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-07 04:01:58', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-06 17:03:45', NULL, 32115, 600, 400, NULL, NULL, NULL, NULL, NULL, '{}'),
	('30faf29f-51d4-4b3e-b15a-fb63ab9b3996', 'local', '30faf29f-51d4-4b3e-b15a-fb63ab9b3996.ico', 'moon.ico', 'Moon', 'image/x-icon', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-01-31 05:34:11', NULL, '2024-01-30 18:34:12', NULL, 318, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('4261f2ea-fd24-4571-9a38-8b157c459a66', 'local', '4261f2ea-fd24-4571-9a38-8b157c459a66.png', 'ip.png', 'IP', 'image/png', '3088d1c0-4981-44f9-9eaf-0515c7b41fbe', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-07 05:18:43', NULL, '2024-02-06 18:18:44', NULL, 65329, 1128, 682, NULL, NULL, NULL, NULL, NULL, '{}'),
	('61a35d5e-982a-4fe2-8e62-c3c08c1eeaa8', 'local', '61a35d5e-982a-4fe2-8e62-c3c08c1eeaa8.png', 'Vost_Ehabi_1.png', 'Vost Ehabi 1', 'image/png', '9e16651f-f221-4b22-a7ff-d04cc325aadb', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 23:48:22', NULL, '2024-02-27 12:48:22', NULL, 1141583, 2997, 8867, NULL, NULL, NULL, NULL, NULL, '{}'),
	('7bcf73cd-75f5-4e06-920a-cfacd5e64d8e', 'local', '7bcf73cd-75f5-4e06-920a-cfacd5e64d8e.png', 'Ehabi_1.png', 'Ehabi_1', 'image/png', '9e16651f-f221-4b22-a7ff-d04cc325aadb', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 23:35:04', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 12:47:55', NULL, 3406045, 4630, 8317, NULL, NULL, NULL, NULL, NULL, '{}'),
	('8235f740-421f-4067-bfa2-9f674a3c8d65', 'local', '8235f740-421f-4067-bfa2-9f674a3c8d65.jpeg', 'don.jpeg', 'Don', 'image/jpeg', '2d89c3bf-505c-4ebf-acc3-fc3d7c0ac803', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-07 03:45:44', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-06 18:26:02', NULL, 36023, 400, 300, NULL, NULL, NULL, NULL, '["public"]', '{}'),
	('8374b5b8-94a2-42f4-b85c-7a7eb6a61251', 'local', '8374b5b8-94a2-42f4-b85c-7a7eb6a61251.jpg', '000005-Куся биг.jpg', '000005 Куся Биг', 'image/jpeg', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-01-31 00:43:40', NULL, '2024-01-30 13:43:40', NULL, 36629, 448, 448, NULL, NULL, NULL, NULL, NULL, '{}'),
	('95f701b1-b319-4db2-af20-03f6c3082ea7', 'local', '95f701b1-b319-4db2-af20-03f6c3082ea7.pdf', 'order_blank_138317065_205816236.pdf', 'Order Blank 138317065 205816236', 'application/pdf', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-10 12:58:16', NULL, '2024-02-10 01:58:16', NULL, 81652, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
	('98589669-5c29-497b-87aa-c2dc4357e709', 'local', '98589669-5c29-497b-87aa-c2dc4357e709.png', 'Ehabi2.png', 'Ehabi2', 'image/png', '9e16651f-f221-4b22-a7ff-d04cc325aadb', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-28 10:53:15', NULL, '2024-02-27 23:53:16', NULL, 24617427, 4922, 8476, NULL, NULL, NULL, NULL, NULL, '{}'),
	('9c145e08-0d9a-460f-9d0c-734e38f3e28f', 'local', '9c145e08-0d9a-460f-9d0c-734e38f3e28f.jpg', 'image002.jpg', 'image002.jpg', 'image/jpeg', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-12 05:42:33', NULL, '2024-02-11 18:42:34', NULL, 33990, 392, 394, NULL, NULL, NULL, NULL, NULL, '{}'),
	('a874615b-dd74-424d-b46f-b48684b6df03', 'local', 'a874615b-dd74-424d-b46f-b48684b6df03.png', 'deneg-net.png', 'Deneg Net', 'image/png', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-22 07:54:18', NULL, '2024-02-21 20:54:19', NULL, 190087, 305, 305, NULL, NULL, NULL, NULL, NULL, '{}'),
	('ab24710e-3736-4f6a-a6c8-cd0961d56505', 'local', 'ab24710e-3736-4f6a-a6c8-cd0961d56505.jpg', 'ezh.jpg', 'ezh.jpg', 'image/jpeg', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-12 05:22:21', NULL, '2024-02-11 18:22:22', NULL, 30997, 350, 236, NULL, NULL, NULL, NULL, NULL, '{}'),
	('b4f301cf-a6a8-4353-8dcb-915981bb4dde', 'local', 'b4f301cf-a6a8-4353-8dcb-915981bb4dde.jpg', '1695838311_gas-kvas-com-p-kartinki-popugaev-44.jpg', 'Carrot', 'image/jpeg', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-07 11:52:37', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-07 00:58:21', NULL, 137320, 768, 1024, NULL, NULL, NULL, NULL, NULL, '{}'),
	('b659db0b-a860-488e-9025-8e735875e9e7', 'local', 'b659db0b-a860-488e-9025-8e735875e9e7.jpg', 'zai.jpg', 'Zai', 'image/jpeg', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-01-31 06:07:10', NULL, '2024-01-30 19:07:10', NULL, 49473, 400, 300, NULL, NULL, NULL, NULL, NULL, '{}'),
	('b9f57613-5fee-49d9-94cf-84466c7de17c', 'local', 'b9f57613-5fee-49d9-94cf-84466c7de17c.jpg', 'd379f1f1eaf887b71f2c4a232d5360c4.jpg', 'Сияние', 'image/jpeg', '456f41cb-c43d-4e47-b019-5867bd863a72', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-07 04:02:28', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-06 17:03:45', NULL, 139770, 736, 919, NULL, NULL, NULL, NULL, NULL, '{}'),
	('be733b70-2851-4ef1-869f-624adfc925b2', 'local', 'be733b70-2851-4ef1-869f-624adfc925b2.jpg', 'lemur.jpg', 'Lemur', 'image/jpeg', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-01 23:47:40', NULL, '2024-02-01 12:47:41', NULL, 74884, 900, 900, NULL, NULL, NULL, NULL, NULL, '{}'),
	('d591def9-9c1f-4928-8828-aaee6b9defc4', 'local', 'd591def9-9c1f-4928-8828-aaee6b9defc4.png', 'Vost_Ehabi_2.png', 'Vost Ehabi 2', 'image/png', '9e16651f-f221-4b22-a7ff-d04cc325aadb', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-28 04:58:08', NULL, '2024-02-27 17:58:08', NULL, 6266876, 3020, 8902, NULL, NULL, NULL, NULL, NULL, '{}'),
	('da6d644e-2c4e-4f6e-a1e2-6f42eecaf8d2', 'local', 'da6d644e-2c4e-4f6e-a1e2-6f42eecaf8d2.jpg', '2.jpg', '2.jpg', 'image/jpeg', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-12 05:16:17', NULL, '2024-02-11 18:16:18', NULL, 249192, 1391, 1000, NULL, NULL, NULL, NULL, NULL, '{}'),
	('e7c9a41f-27e6-4455-811c-7939423b3450', 'local', 'e7c9a41f-27e6-4455-811c-7939423b3450.jpeg', '18.jpeg', '18', 'image/jpeg', '5ae79ceb-3e85-42f4-a790-d8cf968dedf3', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-07 03:20:29', NULL, '2024-02-06 16:20:29', NULL, 93853, 1025, 681, NULL, NULL, NULL, NULL, NULL, '{}'),
	('ff759ccb-d890-48b2-ba67-fe371f33f30e', 'local', 'ff759ccb-d890-48b2-ba67-fe371f33f30e.jpg', '3.jpg', '3.jpg', 'image/jpeg', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-12 04:20:30', NULL, '2024-02-11 17:20:31', NULL, 53263, 736, 433, NULL, NULL, NULL, NULL, NULL, '{}');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
