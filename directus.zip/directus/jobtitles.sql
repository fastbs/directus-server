-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.jobtitles
CREATE TABLE IF NOT EXISTS `jobtitles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `name_short` varchar(255) DEFAULT NULL,
  `company` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobtitles_user_created_foreign` (`user_created`),
  KEY `jobtitles_user_updated_foreign` (`user_updated`),
  KEY `jobtitles_company_foreign` (`company`),
  CONSTRAINT `jobtitles_company_foreign` FOREIGN KEY (`company`) REFERENCES `companies` (`id`),
  CONSTRAINT `jobtitles_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `jobtitles_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.jobtitles: ~9 rows (приблизительно)
INSERT INTO `jobtitles` (`id`, `user_created`, `date_created`, `user_updated`, `date_updated`, `name`, `name_short`, `company`) VALUES
	(1, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 13:17:05', NULL, NULL, 'Генеральный директор', 'Ген. директор', 81),
	(2, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 13:17:37', NULL, NULL, 'Главный инженер', 'Гл. инженер', 81),
	(3, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-13 13:19:04', NULL, NULL, 'Мастер оф юниверс', 'МОЮ', 84),
	(4, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-13 13:22:09', NULL, NULL, 'Главный дворник', 'Гл. дворник', 85),
	(53, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-14 18:57:12', NULL, NULL, 'Помощник дворника', 'Помдворник', 85),
	(54, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-14 19:11:03', NULL, NULL, 'Убийца дворников', 'УД', 94),
	(61, '6013ca28-b4bd-4a96-a2db-bccc6a0510fa', '2024-02-15 01:03:39', NULL, NULL, 'Главный Псевдо Заяц', 'ГПЗ', 95),
	(63, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-15 14:35:39', NULL, NULL, 'Проверка раз-раз!', '', 84),
	(78, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-16 17:06:25', NULL, NULL, 'From Main', 'fm', 81),
	(79, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-17 23:16:02', NULL, NULL, 'From Main', 'fm', 81),
	(80, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-17 23:16:05', NULL, NULL, 'From Main', 'fm', 81),
	(81, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 18:14:47', NULL, NULL, 'Фекальный мастер', 'Фекмастер', 85),
	(82, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 18:17:08', NULL, NULL, 'Ассенизатор погружной', 'Асспогр', 85);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
