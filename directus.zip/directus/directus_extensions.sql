-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_extensions
CREATE TABLE IF NOT EXISTS `directus_extensions` (
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `id` char(36) NOT NULL,
  `folder` varchar(255) NOT NULL,
  `source` varchar(255) NOT NULL,
  `bundle` char(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_extensions: ~12 rows (приблизительно)
INSERT INTO `directus_extensions` (`enabled`, `id`, `folder`, `source`, `bundle`) VALUES
	(1, '002c0c4c-35b7-4fdc-9ce5-aad385b9a0be', 'directus-extension-fastbs_bundle', 'local', NULL),
	(1, '17da25ed-916e-4851-b1bc-5aea04588507', 'directus-extension-directus-ext-fbs_bundle', 'local', NULL),
	(1, '1dfe9729-4ee6-478f-b750-df26333393ff', 'fastbs.module', 'local', '9012f922-fab8-4fa0-b4ac-fc0730914b5e'),
	(1, '1ff38923-6bc2-43ca-8f08-f5d2cdb12bbb', 'fastbs.interface.collection.selector', 'local', '9012f922-fab8-4fa0-b4ac-fc0730914b5e'),
	(1, '3220d236-c648-4610-a7b8-5571b2739b3a', 'fbs.hook', 'local', '17da25ed-916e-4851-b1bc-5aea04588507'),
	(1, '4563fdb0-5573-4f70-aa79-8c1d15350d67', 'fastbs.interface.collection.selector', 'local', '002c0c4c-35b7-4fdc-9ce5-aad385b9a0be'),
	(1, '792f2578-805c-41cf-8339-19afbab9f45e', 'fbs.interface', 'local', '17da25ed-916e-4851-b1bc-5aea04588507'),
	(1, '7d6d72db-b7a8-434a-b8ed-49b970799f90', 'fastbs.hook', 'local', '002c0c4c-35b7-4fdc-9ce5-aad385b9a0be'),
	(1, '9012f922-fab8-4fa0-b4ac-fc0730914b5e', 'directus-extension-fastbs_collection_rules', 'local', NULL),
	(1, '92a90234-4ed9-48e7-9783-0fce83ff6e05', 'reports', 'local', '9012f922-fab8-4fa0-b4ac-fc0730914b5e'),
	(1, 'b1ce18cd-ea12-4401-aca0-e8b756228675', 'fbs.module', 'local', '17da25ed-916e-4851-b1bc-5aea04588507'),
	(1, 'ec1806fb-d050-445d-b4fe-3c1dac8576c5', 'fastbs.module', 'local', '002c0c4c-35b7-4fdc-9ce5-aad385b9a0be'),
	(1, 'f86dc71f-d1d8-4c39-8025-81df4f611e30', 'fastbs.hook', 'local', '9012f922-fab8-4fa0-b4ac-fc0730914b5e');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
