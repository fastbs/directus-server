-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_collections
CREATE TABLE IF NOT EXISTS `directus_collections` (
  `collection` varchar(64) NOT NULL,
  `icon` varchar(30) DEFAULT NULL,
  `note` text,
  `display_template` varchar(255) DEFAULT NULL,
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `singleton` tinyint(1) NOT NULL DEFAULT '0',
  `translations` json DEFAULT NULL,
  `archive_field` varchar(64) DEFAULT NULL,
  `archive_app_filter` tinyint(1) NOT NULL DEFAULT '1',
  `archive_value` varchar(255) DEFAULT NULL,
  `unarchive_value` varchar(255) DEFAULT NULL,
  `sort_field` varchar(64) DEFAULT NULL,
  `accountability` varchar(255) DEFAULT 'all',
  `color` varchar(255) DEFAULT NULL,
  `item_duplication_fields` json DEFAULT NULL,
  `sort` int DEFAULT NULL,
  `group` varchar(64) DEFAULT NULL,
  `collapse` varchar(255) NOT NULL DEFAULT 'open',
  `preview_url` varchar(255) DEFAULT NULL,
  `versioning` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`collection`),
  KEY `directus_collections_group_foreign` (`group`),
  CONSTRAINT `directus_collections_group_foreign` FOREIGN KEY (`group`) REFERENCES `directus_collections` (`collection`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_collections: ~14 rows (приблизительно)
INSERT INTO `directus_collections` (`collection`, `icon`, `note`, `display_template`, `hidden`, `singleton`, `translations`, `archive_field`, `archive_app_filter`, `archive_value`, `unarchive_value`, `sort_field`, `accountability`, `color`, `item_duplication_fields`, `sort`, `group`, `collapse`, `preview_url`, `versioning`) VALUES
	('companies', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, NULL, 3, NULL, 'open', NULL, 0),
	('employees', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, '["name", "company.id", "name_short"]', 4, NULL, 'open', NULL, 0),
	('fastbs_bundle_rules', 'control_camera', 'Additional rules for fields actions (CRUD)', NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', '#FF0000', NULL, 5, NULL, 'open', NULL, 0),
	('fastbs_bundle_settings', 'settings', NULL, NULL, 0, 1, NULL, NULL, 1, NULL, NULL, NULL, 'all', '#FF0000', NULL, 6, NULL, 'open', NULL, 0),
	('investigations', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, NULL, NULL, NULL, 'open', NULL, 0),
	('jobtitles', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, '["name", "company.id"]', 7, NULL, 'open', NULL, 0),
	('Maps', 'map', NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', '#2ECDA7', NULL, 2, NULL, 'open', NULL, 0),
	('map_images', 'wallpaper', NULL, NULL, 0, 0, NULL, 'status', 1, 'archived', 'draft', NULL, 'all', '#2ECDA7', NULL, 3, 'Maps', 'open', NULL, 0),
	('map_markers', 'distance', NULL, NULL, 0, 0, NULL, 'status', 1, 'archived', 'draft', NULL, 'all', '#2ECDA7', NULL, 2, 'Maps', 'open', NULL, 0),
	('map_points', 'point_scan', NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', '#2ECDA7', NULL, 1, 'Maps', 'open', NULL, 0),
	('menu', 'menu_book', 'Menu description', NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, NULL, 1, NULL, 'open', NULL, 0),
	('posts', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, 'archived', 'draft', NULL, 'all', NULL, NULL, 9, NULL, 'open', NULL, 0),
	('post_categories', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, NULL, 8, NULL, 'open', NULL, 0),
	('qq', NULL, NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', NULL, NULL, 10, NULL, 'open', NULL, 0),
	('reports', 'library_books', NULL, NULL, 0, 0, NULL, NULL, 1, NULL, NULL, NULL, 'all', '#2ECDA7', NULL, NULL, NULL, 'open', NULL, 0);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
