-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.posts
DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `sort` int DEFAULT NULL,
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `image` char(36) DEFAULT NULL,
  `category` int unsigned DEFAULT NULL,
  `test` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_title_unique` (`title`),
  KEY `posts_user_created_foreign` (`user_created`),
  KEY `posts_user_updated_foreign` (`user_updated`),
  KEY `posts_image_foreign` (`image`),
  KEY `posts_category_foreign` (`category`),
  CONSTRAINT `posts_category_foreign` FOREIGN KEY (`category`) REFERENCES `post_categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_image_foreign` FOREIGN KEY (`image`) REFERENCES `directus_files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `posts_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.posts: ~8 rows (приблизительно)
INSERT INTO `posts` (`id`, `status`, `sort`, `user_created`, `date_created`, `user_updated`, `date_updated`, `title`, `description`, `image`, `category`, `test`) VALUES
	(1, 'draft', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-06 11:49:36', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-11 01:36:00', 'From admin', 'Описание просто гениальное!', 'b4f301cf-a6a8-4353-8dcb-915981bb4dde', 1, NULL),
	(3, 'draft', NULL, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-06 11:57:46', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-11 02:53:19', 'Update attempt - User upd', NULL, '4261f2ea-fd24-4571-9a38-8b157c459a66', 1, NULL),
	(5, 'draft', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 12:30:21', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-11 12:59:44', 'Nef with file', '12345', 'e7c9a41f-27e6-4455-811c-7939423b3450', 1, NULL),
	(7, 'draft', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 17:20:31', NULL, NULL, 'Заголовок с картинкой', 'Описание', 'ff759ccb-d890-48b2-ba67-fe371f33f30e', 1, NULL),
	(8, 'draft', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 18:16:18', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 18:49:31', 'aaaaaa', 'bbbbbb', 'da6d644e-2c4e-4f6e-a1e2-6f42eecaf8d2', 1, NULL),
	(9, 'draft', NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 18:40:12', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-11 18:48:11', 'vvvvvvvv', 'ddddddddd', NULL, 2, NULL),
	(12, 'draft', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-17 15:55:19', NULL, NULL, '12345', '123', NULL, 1, NULL),
	(13, 'draft', NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-17 22:53:17', NULL, NULL, '123', NULL, NULL, 2, NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
