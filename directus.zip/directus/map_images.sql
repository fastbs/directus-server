-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.map_images
CREATE TABLE IF NOT EXISTS `map_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` char(36) DEFAULT NULL,
  `point1` int unsigned DEFAULT NULL,
  `point2` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `map_images_user_created_foreign` (`user_created`),
  KEY `map_images_user_updated_foreign` (`user_updated`),
  KEY `map_images_image_foreign` (`image`),
  KEY `map_images_point1_foreign` (`point1`),
  KEY `map_images_point2_foreign` (`point2`),
  CONSTRAINT `map_images_image_foreign` FOREIGN KEY (`image`) REFERENCES `directus_files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `map_images_point1_foreign` FOREIGN KEY (`point1`) REFERENCES `map_points` (`id`) ON DELETE SET NULL,
  CONSTRAINT `map_images_point2_foreign` FOREIGN KEY (`point2`) REFERENCES `map_points` (`id`) ON DELETE SET NULL,
  CONSTRAINT `map_images_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `map_images_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.map_images: ~4 rows (приблизительно)
INSERT INTO `map_images` (`id`, `status`, `user_created`, `date_created`, `user_updated`, `date_updated`, `name`, `image`, `point1`, `point2`) VALUES
	(1, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 12:40:41', NULL, NULL, 'Эхаби', '7bcf73cd-75f5-4e06-920a-cfacd5e64d8e', 1, 2),
	(2, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 13:01:07', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 18:07:14', 'Восточное Эхаби 1', '61a35d5e-982a-4fe2-8e62-c3c08c1eeaa8', 3, 4),
	(3, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 17:58:42', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 18:08:33', 'Восточное Эхаби - версия 2', 'd591def9-9c1f-4928-8828-aaee6b9defc4', 8, 7),
	(4, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-27 23:57:23', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-28 00:01:20', 'Эхаби - после поворота', '98589669-5c29-497b-87aa-c2dc4357e709', 9, 10);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
