-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_users
CREATE TABLE IF NOT EXISTS `directus_users` (
  `id` char(36) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `description` text,
  `tags` json DEFAULT NULL,
  `avatar` char(36) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `tfa_secret` varchar(255) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'active',
  `role` char(36) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `last_access` timestamp NULL DEFAULT NULL,
  `last_page` varchar(255) DEFAULT NULL,
  `provider` varchar(128) NOT NULL DEFAULT 'default',
  `external_identifier` varchar(255) DEFAULT NULL,
  `auth_data` json DEFAULT NULL,
  `email_notifications` tinyint(1) DEFAULT '1',
  `appearance` varchar(255) DEFAULT NULL,
  `theme_dark` varchar(255) DEFAULT NULL,
  `theme_light` varchar(255) DEFAULT NULL,
  `theme_light_overrides` json DEFAULT NULL,
  `theme_dark_overrides` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `directus_users_external_identifier_unique` (`external_identifier`),
  UNIQUE KEY `directus_users_email_unique` (`email`),
  UNIQUE KEY `directus_users_token_unique` (`token`),
  KEY `directus_users_role_foreign` (`role`),
  CONSTRAINT `directus_users_role_foreign` FOREIGN KEY (`role`) REFERENCES `directus_roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_users: ~4 rows (приблизительно)
INSERT INTO `directus_users` (`id`, `first_name`, `last_name`, `email`, `password`, `location`, `title`, `description`, `tags`, `avatar`, `language`, `tfa_secret`, `status`, `role`, `token`, `last_access`, `last_page`, `provider`, `external_identifier`, `auth_data`, `email_notifications`, `appearance`, `theme_dark`, `theme_light`, `theme_light_overrides`, `theme_dark_overrides`) VALUES
	('1e10999b-4e22-43aa-b6db-c7d0bfa2f010', 'User', NULL, 'user@localhost.com', '$argon2id$v=19$m=65536,t=3,p=4$yhf46OUX7yTGiUvtaVDf0g$x76NVAslkwd/9bAqLQDA7WUcXCv/ObtFJapODMq1V5w', NULL, NULL, NULL, NULL, 'be733b70-2851-4ef1-869f-624adfc925b2', NULL, NULL, 'active', 'de636685-39f5-4119-8368-4410df3656ab', 'IRvVLC1ymGbzlq78wPMnkRGBU3kZ7tam', '2024-06-03 04:52:16', '/content', 'default', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
	('3dc0e39c-4891-473d-8be3-d6080e4b314a', 'Admin', 'User', 'admin@localhost.com', '$argon2id$v=19$m=65536,t=3,p=4$EoXMCGvvxgRtn72Xah2gPQ$oMu66hZQHEico6rOSQpVyB6YjF/RcxqcNHWg00S+tgw', NULL, NULL, NULL, NULL, '8374b5b8-94a2-42f4-b85c-7a7eb6a61251', NULL, NULL, 'active', '9c1faa6c-821c-42dc-9948-53f4b88094e2', 'ery6ggqyrVkUGWyRIHl172MTzzDytWuL', '2024-06-10 22:16:34', '/files/all', 'default', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
	('6013ca28-b4bd-4a96-a2db-bccc6a0510fa', 'PseudoZais', NULL, 'zais@les.ru', '$argon2id$v=19$m=65536,t=3,p=4$+QbjMeKwA55mmsLS1CvlEg$c7KSxlIAzMVXExJ81YSPFmrrmEXqEydS4ZkAwsZDkKM', NULL, NULL, NULL, NULL, 'a874615b-dd74-424d-b46f-b48684b6df03', NULL, NULL, 'active', 'de636685-39f5-4119-8368-4410df3656ab', NULL, '2024-02-15 13:14:59', NULL, 'default', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
	('b99ec054-818d-4d24-b034-12d4552385b3', 'Guest', NULL, 'guest@localhost.com', '$argon2id$v=19$m=65536,t=3,p=4$GLh8/jW8ZcBPpUw5Ou7EGA$6cqlzDV6Mo/7TkSEzUkLnMQPpTlx8cN7LJaGA9TcIU0', NULL, NULL, 'Shared account for an unregistered users', NULL, 'b4f301cf-a6a8-4353-8dcb-915981bb4dde', NULL, NULL, 'active', '5691d77d-1d7a-4a1a-83fa-b717f68726b0', 'gLEGmZ9JMhiTsr6pnKwgWj_Z5RL9jFsi', '2024-02-07 12:49:15', '/content', 'default', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL),
	('ce188df2-446b-485b-82b6-c086c3c16c51', 'Zais', NULL, 'zais@localhost.com', '$argon2id$v=19$m=65536,t=3,p=4$a84+F/wFrWbymWpQyvwcCA$KAT467mftQOzXhSqmhtmpyBivxfkOhcyOWAkJhP7WOs', NULL, NULL, 'I\'m fat!', NULL, 'b659db0b-a860-488e-9025-8e735875e9e7', NULL, NULL, 'active', '1a2e3907-dee2-4ae3-a29f-fd3334593f69', 'Ymh2nvBPlY6C9HivFyZNY-asT4kZ3YKI', '2024-06-10 22:04:00', '/fastbs.module', 'default', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
