-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.map_points
CREATE TABLE IF NOT EXISTS `map_points` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `x` int DEFAULT NULL,
  `y` int DEFAULT NULL,
  `lng` float(15,10) DEFAULT NULL,
  `lat` float(15,10) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `map_image` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `map_points_map_image_foreign` (`map_image`),
  CONSTRAINT `map_points_map_image_foreign` FOREIGN KEY (`map_image`) REFERENCES `map_images` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.map_points: ~21 rows (приблизительно)
INSERT INTO `map_points` (`id`, `x`, `y`, `lng`, `lat`, `comment`, `map_image`) VALUES
	(1, 708, 386, 142.9772644043, 53.5288124084, 'Домик на первых Родниках возле моста', 1),
	(2, 3119, 7661, 142.9983978271, 53.4869651794, 'Тройная скважина в правом нижнем углу', 1),
	(3, 804, 459, 143.0406341553, 53.5219078064, NULL, NULL),
	(4, 2818, 8159, 143.0595855713, NULL, NULL, NULL),
	(6, 811, 461, 143.0406188965, 53.5218963623, NULL, NULL),
	(7, 2909, 8149, 143.0595703125, 53.4779701233, NULL, NULL),
	(8, 1025, 5480, 143.0424041748, 53.4928245544, NULL, NULL),
	(9, 989, 412, 142.9772796631, 53.5288009644, 'Домик на первых Родниках', 4),
	(10, 3136, 7770, 142.9983825684, 53.4869689941, 'Тройная скважина', 4),
	(11, 0, 0, 142.9675598145, 53.5311431885, 'Левый верхний - 0, 0', 4),
	(12, 4895, 8471, 143.0156707764, 53.4829826355, 'Правый нижний угол', 4),
	(13, 1059, 4042, 142.9781799316, 53.5081253052, 'Емкость на нефтепарке', 4),
	(14, 2789, 4424, 142.9947052002, 53.5060958862, 'Будка возле АБК Эхаби', 4),
	(15, 2525, 3549, 142.9922180176, 53.5109977722, 'Тракторный гараж (арочник)', 4),
	(16, 1978, 5549, 142.9867095947, 53.4996757507, 'КНС - большой резервуар', 4),
	(17, 1748, 7093, 142.9850158691, 53.4907722473, 'Двойная лужа', 4),
	(18, 2714, 6823, 142.9943542480, 53.4922599792, 'Скважина рядом со 182', 4),
	(19, 1963, 6296, 142.9870300293, 53.4953231812, 'Будка у дороги', 4),
	(20, 1183, 5359, 142.9794769287, 53.5006217957, 'Будка на запад от КНС на развилке', 4),
	(21, 3422, 3606, 143.0007629395, 53.5107498169, 'Пересечение линий на бывшей подстанции', 4),
	(22, 2013, 5601, 142.9874572754, 53.4992637634, 'КНС - третий резервуар (новый)', 4);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
