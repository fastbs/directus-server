-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_migrations
CREATE TABLE IF NOT EXISTS `directus_migrations` (
  `version` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_migrations: ~71 rows (приблизительно)
INSERT INTO `directus_migrations` (`version`, `name`, `timestamp`) VALUES
	('20201028A', 'Remove Collection Foreign Keys', '2024-01-31 00:36:09'),
	('20201029A', 'Remove System Relations', '2024-01-31 00:36:09'),
	('20201029B', 'Remove System Collections', '2024-01-31 00:36:09'),
	('20201029C', 'Remove System Fields', '2024-01-31 00:36:09'),
	('20201105A', 'Add Cascade System Relations', '2024-01-31 00:36:10'),
	('20201105B', 'Change Webhook URL Type', '2024-01-31 00:36:10'),
	('20210225A', 'Add Relations Sort Field', '2024-01-31 00:36:10'),
	('20210304A', 'Remove Locked Fields', '2024-01-31 00:36:10'),
	('20210312A', 'Webhooks Collections Text', '2024-01-31 00:36:10'),
	('20210331A', 'Add Refresh Interval', '2024-01-31 00:36:10'),
	('20210415A', 'Make Filesize Nullable', '2024-01-31 00:36:10'),
	('20210416A', 'Add Collections Accountability', '2024-01-31 00:36:10'),
	('20210422A', 'Remove Files Interface', '2024-01-31 00:36:10'),
	('20210506A', 'Rename Interfaces', '2024-01-31 00:36:10'),
	('20210510A', 'Restructure Relations', '2024-01-31 00:36:10'),
	('20210518A', 'Add Foreign Key Constraints', '2024-01-31 00:36:10'),
	('20210519A', 'Add System Fk Triggers', '2024-01-31 00:36:11'),
	('20210521A', 'Add Collections Icon Color', '2024-01-31 00:36:11'),
	('20210525A', 'Add Insights', '2024-01-31 00:36:11'),
	('20210608A', 'Add Deep Clone Config', '2024-01-31 00:36:11'),
	('20210626A', 'Change Filesize Bigint', '2024-01-31 00:36:11'),
	('20210716A', 'Add Conditions to Fields', '2024-01-31 00:36:11'),
	('20210721A', 'Add Default Folder', '2024-01-31 00:36:11'),
	('20210802A', 'Replace Groups', '2024-01-31 00:36:11'),
	('20210803A', 'Add Required to Fields', '2024-01-31 00:36:11'),
	('20210805A', 'Update Groups', '2024-01-31 00:36:11'),
	('20210805B', 'Change Image Metadata Structure', '2024-01-31 00:36:11'),
	('20210811A', 'Add Geometry Config', '2024-01-31 00:36:11'),
	('20210831A', 'Remove Limit Column', '2024-01-31 00:36:11'),
	('20210903A', 'Add Auth Provider', '2024-01-31 00:36:11'),
	('20210907A', 'Webhooks Collections Not Null', '2024-01-31 00:36:11'),
	('20210910A', 'Move Module Setup', '2024-01-31 00:36:11'),
	('20210920A', 'Webhooks URL Not Null', '2024-01-31 00:36:11'),
	('20210924A', 'Add Collection Organization', '2024-01-31 00:36:11'),
	('20210927A', 'Replace Fields Group', '2024-01-31 00:36:11'),
	('20210927B', 'Replace M2M Interface', '2024-01-31 00:36:11'),
	('20210929A', 'Rename Login Action', '2024-01-31 00:36:11'),
	('20211007A', 'Update Presets', '2024-01-31 00:36:11'),
	('20211009A', 'Add Auth Data', '2024-01-31 00:36:12'),
	('20211016A', 'Add Webhook Headers', '2024-01-31 00:36:12'),
	('20211103A', 'Set Unique to User Token', '2024-01-31 00:36:12'),
	('20211103B', 'Update Special Geometry', '2024-01-31 00:36:12'),
	('20211104A', 'Remove Collections Listing', '2024-01-31 00:36:12'),
	('20211118A', 'Add Notifications', '2024-01-31 00:36:12'),
	('20211211A', 'Add Shares', '2024-01-31 00:36:12'),
	('20211230A', 'Add Project Descriptor', '2024-01-31 00:36:12'),
	('20220303A', 'Remove Default Project Color', '2024-01-31 00:36:12'),
	('20220308A', 'Add Bookmark Icon and Color', '2024-01-31 00:36:12'),
	('20220314A', 'Add Translation Strings', '2024-01-31 00:36:12'),
	('20220322A', 'Rename Field Typecast Flags', '2024-01-31 00:36:12'),
	('20220323A', 'Add Field Validation', '2024-01-31 00:36:12'),
	('20220325A', 'Fix Typecast Flags', '2024-01-31 00:36:12'),
	('20220325B', 'Add Default Language', '2024-01-31 00:36:12'),
	('20220402A', 'Remove Default Value Panel Icon', '2024-01-31 00:36:12'),
	('20220429A', 'Add Flows', '2024-01-31 00:36:12'),
	('20220429B', 'Add Color to Insights Icon', '2024-01-31 00:36:12'),
	('20220429C', 'Drop Non Null From IP of Activity', '2024-01-31 00:36:12'),
	('20220429D', 'Drop Non Null From Sender of Notifications', '2024-01-31 00:36:12'),
	('20220614A', 'Rename Hook Trigger to Event', '2024-01-31 00:36:12'),
	('20220801A', 'Update Notifications Timestamp Column', '2024-01-31 00:36:12'),
	('20220802A', 'Add Custom Aspect Ratios', '2024-01-31 00:36:12'),
	('20220826A', 'Add Origin to Accountability', '2024-01-31 00:36:13'),
	('20230401A', 'Update Material Icons', '2024-01-31 00:36:13'),
	('20230525A', 'Add Preview Settings', '2024-01-31 00:36:13'),
	('20230526A', 'Migrate Translation Strings', '2024-01-31 00:36:13'),
	('20230721A', 'Require Shares Fields', '2024-01-31 00:36:13'),
	('20230823A', 'Add Content Versioning', '2024-01-31 00:36:13'),
	('20230927A', 'Themes', '2024-01-31 00:36:13'),
	('20231009A', 'Update CSV Fields to Text', '2024-01-31 00:36:13'),
	('20231009B', 'Update Panel Options', '2024-01-31 00:36:13'),
	('20231010A', 'Add Extensions', '2024-01-31 00:36:13'),
	('20231215A', 'Add Focalpoints', '2024-03-13 06:47:18'),
	('20240122A', 'Add Report URL Fields', '2024-06-03 03:09:21'),
	('20240204A', 'Marketplace', '2024-03-13 06:47:18'),
	('20240305A', 'Change Useragent Type', '2024-06-03 03:09:21'),
	('20240311A', 'Deprecate Webhooks', '2024-06-03 03:09:21'),
	('20240422A', 'Public Registration', '2024-06-03 03:09:21'),
	('20240515A', 'Add Session Window', '2024-06-03 03:09:21');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
