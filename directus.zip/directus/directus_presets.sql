-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.directus_presets
CREATE TABLE IF NOT EXISTS `directus_presets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `bookmark` varchar(255) DEFAULT NULL,
  `user` char(36) DEFAULT NULL,
  `role` char(36) DEFAULT NULL,
  `collection` varchar(64) DEFAULT NULL,
  `search` varchar(100) DEFAULT NULL,
  `layout` varchar(100) DEFAULT 'tabular',
  `layout_query` json DEFAULT NULL,
  `layout_options` json DEFAULT NULL,
  `refresh_interval` int DEFAULT NULL,
  `filter` json DEFAULT NULL,
  `icon` varchar(30) DEFAULT 'bookmark',
  `color` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `directus_presets_collection_foreign` (`collection`),
  KEY `directus_presets_user_foreign` (`user`),
  KEY `directus_presets_role_foreign` (`role`),
  CONSTRAINT `directus_presets_role_foreign` FOREIGN KEY (`role`) REFERENCES `directus_roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `directus_presets_user_foreign` FOREIGN KEY (`user`) REFERENCES `directus_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.directus_presets: ~21 rows (приблизительно)
INSERT INTO `directus_presets` (`id`, `bookmark`, `user`, `role`, `collection`, `search`, `layout`, `layout_query`, `layout_options`, `refresh_interval`, `filter`, `icon`, `color`) VALUES
	(1, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'directus_users', NULL, 'cards', '{"cards": {"page": 1, "sort": ["email"]}}', '{"cards": {"icon": "account_circle", "size": 4, "title": "{{ first_name }} {{ last_name }}", "subtitle": "{{ email }}"}}', NULL, NULL, 'bookmark', NULL),
	(2, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'directus_users', NULL, 'cards', '{"cards": {"page": 1, "sort": ["email"]}}', '{"cards": {"icon": "account_circle", "size": 3, "title": "{{ first_name }} {{ last_name }}", "subtitle": "{{ email }}"}}', NULL, NULL, 'bookmark', NULL),
	(3, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'post_categorys', NULL, NULL, '{"tabular": {"fields": ["name", "id"]}}', NULL, NULL, NULL, 'bookmark', NULL),
	(4, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'posts', NULL, 'tabular', '{"tabular": {"page": 1, "fields": ["status", "category_id", "title", "user_created", "user_created.role.name", "user_updated"]}}', '{"tabular": {"widths": {"title": 261}}}', NULL, NULL, 'bookmark', NULL),
	(7, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'menu', NULL, NULL, '{"tabular": {"page": 1, "fields": ["id", "name", "parent", "route", "userId"]}}', '{"tabular": {"widths": {"userId": 449}}}', NULL, NULL, 'bookmark', NULL),
	(8, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'posts', NULL, 'tabular', '{"tabular": {"fields": ["id", "category", "title", "user_created", "user_created.email", "image", "far"]}}', '{"tabular": {"widths": {"id": 122, "user_created.email": 246}}}', NULL, NULL, 'bookmark', NULL),
	(9, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'menu', NULL, NULL, '{"tabular": {"page": 1}}', NULL, NULL, NULL, 'bookmark', NULL),
	(10, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'directus_files', NULL, 'cards', '{"cards": {"page": 1, "sort": ["-uploaded_on"]}}', '{"cards": {"icon": "insert_drive_file", "size": 4, "title": "{{ title }}", "imageFit": "crop", "subtitle": "{{ type }} • {{ filesize }}"}}', NULL, NULL, 'bookmark', NULL),
	(11, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'directus_files', NULL, 'cards', '{"cards": {"page": 1, "sort": ["-uploaded_on"]}}', '{"cards": {"icon": "insert_drive_file", "size": 4, "title": "{{ title }}", "imageFit": "crop", "subtitle": "{{ type }} • {{ filesize }}"}}', NULL, NULL, 'bookmark', NULL),
	(12, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'directus_files', NULL, 'cards', '{"cards": {"page": 1, "sort": ["-uploaded_on"]}}', '{"cards": {"icon": "insert_drive_file", "size": 4, "title": "{{ title }}", "imageFit": "crop", "subtitle": "{{ type }} • {{ filesize }}"}}', NULL, NULL, 'bookmark', NULL),
	(13, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'post_categories', NULL, NULL, '{"tabular": {"fields": ["id", "name"]}}', '{"tabular": {"widths": {}}}', NULL, NULL, 'bookmark', NULL),
	(14, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'jobtitles', NULL, NULL, '{"tabular": {"fields": ["id", "name", "name_short", "company", "company.name", "user_created.first_name", "user_created", "user_updated"]}}', '{"tabular": {"widths": {"id": 79, "name": 252, "company.name": 239}}}', NULL, NULL, 'bookmark', NULL),
	(15, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'jobtitles', NULL, NULL, '{"tabular": {"fields": ["company", "company.name", "name", "name_short", "user_created"]}}', '{"tabular": {"widths": {"company": 120, "company.name": 505}}}', NULL, NULL, 'bookmark', NULL),
	(16, NULL, 'ce188df2-446b-485b-82b6-c086c3c16c51', NULL, 'jobtitles', NULL, NULL, '{"tabular": {"fields": ["id", "company", "company.name", "name", "name_short", "user_created", "company.user_created"]}}', '{"tabular": {"widths": {"id": 32, "company": 121, "company.name": 460}}}', NULL, NULL, 'bookmark', NULL),
	(17, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'employees', NULL, NULL, '{"tabular": {"fields": ["id", "company", "name", "name_short", "user_created", "company.name"]}}', '{"tabular": {"widths": {"id": 96, "company.name": 382}}}', NULL, NULL, 'bookmark', NULL),
	(18, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'rules', NULL, NULL, '{"tabular": {"page": 1, "sort": ["id"], "fields": ["id", "name", "event", "collection", "related_collection", "success", "active", "rule", "errorMessage"]}}', '{"tabular": {"widths": {"id": 51, "name": 292, "rule": 663, "event": 113, "active": 100, "success": 115, "errorMessage": 375, "related_collection": 176}}}', NULL, NULL, 'bookmark', NULL),
	(19, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'companies', NULL, NULL, '{"tabular": {"fields": ["inn", "name", "name_short", "user_created"]}}', '{"tabular": {"widths": {"name": 731}}}', NULL, NULL, 'bookmark', NULL),
	(20, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'map_points', NULL, NULL, '{"tabular": {"page": 1, "fields": ["id", "x", "y", "lat", "lng", "map_image.name", "comment"]}}', '{"tabular": {"widths": {"comment": 373, "map_image.name": 287}}}', NULL, NULL, 'bookmark', NULL),
	(21, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'map_images', NULL, NULL, '{"tabular": {"page": 1, "fields": ["id", "image", "name", "user_created", "point1", "point2", "image.width", "image.height"]}}', '{"tabular": {"widths": {"image": 439}}}', NULL, NULL, 'bookmark', NULL),
	(22, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'map_markers', NULL, NULL, '{"tabular": {"page": 1, "fields": ["id", "map_image", "map_image.name", "name", "comment", "x", "y"]}}', '{"tabular": {"widths": {"id": 93, "name": 270, "comment": 233, "map_image.name": 282}}}', NULL, NULL, 'bookmark', NULL),
	(23, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'map_markers', NULL, NULL, '{"tabular": {"page": 1, "fields": ["id", "map_image", "status", "x", "y", "name", "comment", "user_created"]}}', '{"tabular": {"widths": {"x": 74, "y": 92, "id": 96, "map_image": 153}}}', NULL, NULL, 'bookmark', NULL),
	(24, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'investigations', NULL, NULL, '{"tabular": {"page": 1, "fields": ["company", "title", "description", "image", "user_created"]}}', '{"tabular": {"widths": {}}}', NULL, NULL, 'bookmark', NULL),
	(25, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'fastbs_bundle_rules', NULL, NULL, '{"tabular": {"fields": ["collection", "event", "name", "related_collection"]}}', '{"tabular": {"widths": {"name": 576}}}', NULL, NULL, 'bookmark', NULL),
	(26, NULL, '3dc0e39c-4891-473d-8be3-d6080e4b314a', NULL, 'reports', NULL, NULL, '{"tabular": {"fields": ["id", "name", "template_file_name"]}}', '{"tabular": {"widths": {}}}', NULL, NULL, 'bookmark', NULL);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
