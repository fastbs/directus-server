-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.companies
CREATE TABLE IF NOT EXISTS `companies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `name_short` varchar(255) DEFAULT NULL,
  `inn` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `companies_user_created_foreign` (`user_created`),
  KEY `companies_user_updated_foreign` (`user_updated`),
  CONSTRAINT `companies_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `companies_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.companies: ~8 rows (приблизительно)
INSERT INTO `companies` (`id`, `user_created`, `date_created`, `user_updated`, `date_updated`, `name`, `name_short`, `inn`) VALUES
	(81, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 02:33:25', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 02:34:03', 'Общество с ограниченной ответственностью "Ядерный рассвет"', 'ООО "Ядерный рассвет"', '6506000003'),
	(82, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 11:15:23', NULL, NULL, 'Общество с ограниченной ответственностью "Новое"', 'ООО "Новое"', '6506000005'),
	(83, 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-02-13 11:15:23', NULL, NULL, 'Акционерное общество "Копытные рога"', 'АО "Копытные рога"', '7705012345'),
	(84, '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-02-13 11:17:19', NULL, NULL, 'Закрытое акционерное общество "Наше дело"', 'ЗАО "Коза Ностра"', '6506000666'),
	(85, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-13 11:19:56', '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-03-25 11:01:48', 'Компания пользователя User - ООО "Юзер Ушастый"', 'ООО "Юзер Ушастый"', '2501000001'),
	(94, '1e10999b-4e22-43aa-b6db-c7d0bfa2f010', '2024-02-14 18:58:10', NULL, NULL, 'Еще одна компания юзера', '', ''),
	(95, '6013ca28-b4bd-4a96-a2db-bccc6a0510fa', '2024-02-15 01:03:01', NULL, NULL, 'Компания Псевдо Зайца', '', '');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
