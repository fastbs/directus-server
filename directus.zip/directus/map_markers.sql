-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               8.0.19 - MySQL Community Server - GPL
-- Операционная система:         Win64
-- HeidiSQL Версия:              12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица directus.map_markers
CREATE TABLE IF NOT EXISTS `map_markers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `user_created` char(36) DEFAULT NULL,
  `date_created` timestamp NULL DEFAULT NULL,
  `user_updated` char(36) DEFAULT NULL,
  `date_updated` timestamp NULL DEFAULT NULL,
  `x` int DEFAULT NULL,
  `y` int DEFAULT NULL,
  `lng` float(15,10) DEFAULT NULL,
  `lat` float(15,10) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `map_image` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `map_markers_user_created_foreign` (`user_created`),
  KEY `map_markers_user_updated_foreign` (`user_updated`),
  KEY `map_markers_map_image_foreign` (`map_image`),
  CONSTRAINT `map_markers_map_image_foreign` FOREIGN KEY (`map_image`) REFERENCES `map_images` (`id`) ON DELETE SET NULL,
  CONSTRAINT `map_markers_user_created_foreign` FOREIGN KEY (`user_created`) REFERENCES `directus_users` (`id`),
  CONSTRAINT `map_markers_user_updated_foreign` FOREIGN KEY (`user_updated`) REFERENCES `directus_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы directus.map_markers: ~5 rows (приблизительно)
INSERT INTO `map_markers` (`id`, `status`, `user_created`, `date_created`, `user_updated`, `date_updated`, `x`, `y`, `lng`, `lat`, `name`, `comment`, `map_image`) VALUES
	(1, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-03-04 18:24:29', NULL, NULL, 989, 412, 142.9772796631, 53.5288009644, 'Домик на первых Родниках', 'Ручной ввод', 4),
	(2, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-03-04 18:26:49', NULL, NULL, 1363, 283, 142.9808654785, 53.5295372009, 'Первая дача', 'Ручной ввод', 4),
	(4, 'draft', '3dc0e39c-4891-473d-8be3-d6080e4b314a', '2024-03-04 18:48:34', NULL, NULL, 813, 274, 142.9755554199, 53.5295867920, 'Лисий дом', 'Ручной ввод', 4),
	(5, 'draft', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-03-05 18:59:15', NULL, NULL, 1338, 160, 142.9806213379, 53.5302352905, 'Руины', 'Первый', 4),
	(7, 'draft', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-03-05 19:02:32', 'ce188df2-446b-485b-82b6-c086c3c16c51', '2024-03-05 19:21:30', 1114, 345, 142.9787750244, 53.5291786194, 'FFF', 'ла-ла', 4);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
