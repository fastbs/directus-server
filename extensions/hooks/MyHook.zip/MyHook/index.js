//import { useApi } from '@directus/extensions-sdk';
import { createError } from '@directus/errors';

/*
The register function receives an object containing the type-specific register functions as the first parameter:
	filter — Listen for a filter event (before the event is emitted)
	action — Listen for an action event (after a defined event)
	init — Listen for an init event
	schedule — Execute a function at certain points in time
	embed — Inject custom JavaScript or CSS within the Data Studio

The second parameter is a context object with the following properties:
	services — All API internal services
	database — Knex instance that is connected to the current database
	getSchema — Async function that reads the full available schema for use in services
	env — Parsed environment variables
	logger — Pino instance.
	emitter — Event emitter instance that can be used to emit custom events for other extensions.
*/

/*
(<collection>.)items.query		The items query			collection
(<collection>.)items.read		The read item			query, collection
(<collection>.)items.create		The new item			collection
(<collection>.)items.update		The updated item		keys, collection
(<collection>.)items.promote	The promoted item		collection, item, version
(<collection>.)items.delete		The keys of the item	collection
*/


/*
The filter register function receives two parameters:
	The event name
	A callback function that is executed whenever the event is emitted.

The callback function itself receives three parameters:
	The modifiable payload
	An event-specific meta object
	A context object

The context object has the following properties:
	database — The current database transaction
	schema — The current API schema in use
	accountability — Information about the current user
*/

//const $MACROS = ["$CURRENT_USER", "$CURRENT_ROLE", "$NOW", "$PAYLOAD"];
let $CURRENT_USER = "";
let $CURRENT_ROLE = "";
let $NOW = 0;
let $PAYLOAD = "";
let $KEYS = "";

function replaceMacro(item) {
	if (item instanceof Object) {
		for (const key in item) {
			if (item[key] instanceof Object) {
				replaceMacro(item[key]);
			}
			else {
				item[key] = item[key].replace(/^\s*{{\s*((\$\w+)(\.\w+)*)\s*}}\s*$/gi, str => eval(str));
			}
		}
	}
}

let js = {
	"_and": [
		{ "id": { "_neq": "{{$KEYS.0}}" } },
		{ "name": { "_eq": "{{$PAYLOAD.name}}" } },
		{ "company": { "_eq": "{{$PAYLOAD.company}}" } }
	]
}



export default ({ filter, action }, ctx) => {

	console.log("************* ENTER HOOK ************* ");
	//console.log("********** ctx:", ctx);

	async function rulesCheck(payload, meta, context) {
		const { schema, accountability, database } = context;
		const { ItemsService } = ctx.services;
		$CURRENT_USER = accountability.user;
		$CURRENT_ROLE = accountability.role;
		$NOW = Math.round(Date.now() / 1000);
		$PAYLOAD = payload;
		$KEYS = Array.isArray(meta.keys) ? meta.keys.reduce((acc, cur, i) => { acc["key" + i] = cur; return acc; }, {}) : {};


		console.log("\n\n********** My hook:", meta.event, " **********");
		console.log("********** payload:", payload);
		console.log("********** meta:", meta);
		console.log("********** $KEYS:", $KEYS);
		//console.log("********** $COUNTRIES:", $COUNTRIES);

		let event = meta.event.replace("items.", "").toUpperCase();

		if (["QUERY", "READ", "CREATE", "UPDATE", "PROMOTE", "DELETE"].includes(event)) {
			const rulesService = new ItemsService('rules', { schema, database });
			const rules = await rulesService.readByQuery({
				fields: ['*'],
				filter: {
					event: {
						_eq: event,
					},
					collection: {
						_eq: meta.collection,  // Коллекция, в которой создается запись
					},
					active: {
						_eq: true,
					}
				},
			});

			for (const rule of rules) {  // Перебираем правила
				console.log("*** RULE:", rule)

				const relService = new ItemsService(rule.related_collection, { schema, database });
				replaceMacro(rule.rule);
				const query = {  // Читаем запись из связанной коллекции, применяя правило (фильтр)
					fields: ['*'],
					filter: rule.rule,
					limit: 1,
				};
				const rel = await relService.readByQuery(query);

				if (Boolean(rel.length) == rule.success) {
					await ctx.logger.info(rule.name + " succesful");
				} else {
					let mes = ` [${event}] ${rule.name} : ${rule.errorMessage}`;
					await ctx.logger.error(mes);
					const PayloadError = createError('INVALID_PAYLOAD', mes, 400);
					throw new PayloadError();
				}
			}
		}

		return payload;
	}

	filter('items.create', rulesCheck);
	filter('items.update', rulesCheck);
	filter('items.delete', rulesCheck);
	//filter('items.query', rulesCheck);
	//filter('items.read', rulesCheck);
	//filter('items.promote', rulesCheck);
};
