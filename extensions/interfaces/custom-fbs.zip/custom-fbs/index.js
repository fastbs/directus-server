import { useStores, defineInterface } from '@directus/extensions-sdk';
import { defineComponent, ref, watch, resolveComponent, openBlock, createBlock } from 'vue';

var _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "interface",
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    collection: {
      type: String,
      required: true
    },
    field: {
      type: String,
      required: true
    },
    value: {
      type: String,
      required: true
    },
    placeholder: {
      type: String,
      default: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u044E"
    }
  },
  emits: ["input"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    console.log(">>> useStores():", useStores());
    const { useCollectionsStore, useSettingsStore, useAppStore } = useStores();
    const collectionsStore = useCollectionsStore();
    console.log(">>> useSettingsStore():", useSettingsStore());
    console.log(">>> useAppStore():", useAppStore());
    let init = true;
    const newValue = ref("");
    const collections = ref(collectionsStore.allCollections.map((x) => {
      return { "text": x.collection, value: x.collection };
    }));
    watch(() => props.value, (nv, pv) => {
      if (init) {
        console.log(">>> Field:", props.field, "  props.value new value: ", nv);
        newValue.value = nv;
      }
    });
    watch(() => newValue.value, (nv, pv) => {
      if (!init) {
        console.log(">>> Field:", props.field, "  emit:", nv);
        emit("input", nv);
      }
      init = false;
    });
    return (_ctx, _cache) => {
      const _component_v_select = resolveComponent("v-select");
      return openBlock(), createBlock(_component_v_select, {
        modelValue: newValue.value,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newValue.value = $event),
        items: collections.value,
        disabled: __props.disabled,
        placeholder: __props.placeholder,
        showDeselect: true
      }, null, 8, ["modelValue", "items", "disabled", "placeholder"]);
    };
  }
});

var _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};

var InterfaceComponent = /* @__PURE__ */ _export_sfc(_sfc_main, [["__file", "interface.vue"]]);

var index = defineInterface({
  id: "fastbs.collection.selector",
  name: "Collection selector",
  icon: "fact_check",
  description: "This is Fastbs custom collection selector interface",
  component: InterfaceComponent,
  types: ["string"],
  relational: false,
  group: "selection",
  options: [
    {
      field: "placeholder",
      type: "string",
      name: "Placeholder",
      meta: {
        interface: "input",
        width: "half",
        options: {
          placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043A\u043E\u043B\u043B\u0435\u043A\u0446\u0438\u044E"
        }
      }
    }
  ]
});

export { index as default };
